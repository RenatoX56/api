#!/bin/bash
# ══════════════════════════════════════════════════════════════════════════════
# install.sh — Instalador del Kali WS Agent + cloudflared tunnel
# Portal SOC — IFX Networks
#
# Uso: sudo bash install.sh
# ══════════════════════════════════════════════════════════════════════════════
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

info()    { echo -e "${CYAN}[INFO]${NC} $*"; }
success() { echo -e "${GREEN}[OK]${NC}   $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

[[ $EUID -ne 0 ]] && error "Ejecutar como root: sudo bash install.sh"

echo -e "${BOLD}═══════════════════════════════════════════════════════${NC}"
echo -e "${BOLD}   Portal SOC — Kali WS Agent Installer${NC}"
echo -e "${BOLD}═══════════════════════════════════════════════════════${NC}"
echo ""

# ── 1. Directorio de instalación ───────────────────────────────────────────────
INSTALL_DIR=/opt/kali-agent
CONFIG_DIR=/etc/kali-agent
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

info "Directorio de instalación: $INSTALL_DIR"
mkdir -p "$INSTALL_DIR" "$CONFIG_DIR"

# ── 2. Python y dependencias ───────────────────────────────────────────────────
info "Verificando Python 3..."
if ! command -v python3 &>/dev/null; then
    info "Instalando Python 3..."
    apt-get update -qq && apt-get install -y python3 python3-venv python3-pip
fi
PYTHON_VER=$(python3 --version)
success "Python: $PYTHON_VER"

info "Creando virtualenv en $INSTALL_DIR/venv..."
python3 -m venv "$INSTALL_DIR/venv"
"$INSTALL_DIR/venv/bin/pip" install --quiet --upgrade pip
"$INSTALL_DIR/venv/bin/pip" install --quiet websockets requests
success "Dependencias instaladas"

# ── 3. Copiar agente ───────────────────────────────────────────────────────────
info "Copiando agent.py..."
cp "$SCRIPT_DIR/agent.py" "$INSTALL_DIR/agent.py"
chmod 750 "$INSTALL_DIR/agent.py"
success "Agente copiado"

# ── 4. Configuración ───────────────────────────────────────────────────────────
CONFIG_FILE="$CONFIG_DIR/agent.env"

if [[ -f "$CONFIG_FILE" ]]; then
    warn "Ya existe $CONFIG_FILE — no se sobreescribe"
    warn "Edita manualmente si necesitas cambiar la configuración"
else
    echo ""
    echo -e "${BOLD}Configuración del agente:${NC}"
    echo ""

    read -rp "  Portal URL [https://200.73.23.246]: " PORTAL_URL
    PORTAL_URL=${PORTAL_URL:-https://200.73.23.246}

    echo ""
    echo -e "  ${YELLOW}IMPORTANTE:${NC} El PENTEST_WS_INTERNAL_SECRET debe ser el mismo"
    echo -e "  que está configurado en el .env del portal Django."
    echo ""
    read -rsp "  PENTEST_WS_INTERNAL_SECRET: " SECRET
    echo ""

    if [[ -z "$SECRET" ]]; then
        warn "No se ingresó secreto — generando uno aleatorio..."
        SECRET=$(python3 -c "import secrets; print(secrets.token_hex(32))")
        echo -e "  ${YELLOW}Secreto generado:${NC} $SECRET"
        echo -e "  ${YELLOW}Configura este valor en el .env del portal:${NC}"
        echo -e "    PENTEST_WS_INTERNAL_SECRET=$SECRET"
        echo ""
    fi

    cat > "$CONFIG_FILE" << EOF
# Kali WS Agent — Configuración
# Generado por install.sh

PORTAL_URL=$PORTAL_URL
PENTEST_WS_INTERNAL_SECRET=$SECRET
AGENT_PORT=8765
AGENT_HOST=127.0.0.1
SHELL=/bin/bash
VERIFY_SSL=false
LOG_LEVEL=INFO
EOF
    chmod 640 "$CONFIG_FILE"
    success "Configuración guardada en $CONFIG_FILE"
fi

# ── 5. Instalar cloudflared ────────────────────────────────────────────────────
if command -v cloudflared &>/dev/null; then
    CF_VER=$(cloudflared --version 2>&1 | head -1)
    success "cloudflared ya instalado: $CF_VER"
else
    info "Instalando cloudflared..."
    ARCH=$(dpkg --print-architecture 2>/dev/null || echo amd64)
    CF_URL="https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-${ARCH}.deb"
    TMP_DEB=$(mktemp /tmp/cloudflared-XXXX.deb)

    if wget -q -O "$TMP_DEB" "$CF_URL"; then
        dpkg -i "$TMP_DEB" &>/dev/null || apt-get install -f -y &>/dev/null
        rm -f "$TMP_DEB"
        success "cloudflared instalado"
    else
        warn "No se pudo descargar cloudflared automáticamente"
        warn "Descarga manual: https://github.com/cloudflare/cloudflared/releases/latest"
        warn "Instala el .deb con: dpkg -i cloudflared-linux-amd64.deb"
    fi
fi

# ── 6. Instalar servicios systemd ─────────────────────────────────────────────
info "Instalando servicios systemd..."

cp "$SCRIPT_DIR/kali-agent.service"          /etc/systemd/system/kali-agent.service
cp "$SCRIPT_DIR/cloudflared-tunnel.service"  /etc/systemd/system/cloudflared-tunnel.service

systemctl daemon-reload
systemctl enable kali-agent.service
systemctl enable cloudflared-tunnel.service
success "Servicios systemd registrados"

# ── 7. Iniciar servicios ───────────────────────────────────────────────────────
info "Iniciando kali-agent..."
systemctl restart kali-agent.service
sleep 2

if systemctl is-active --quiet kali-agent.service; then
    success "kali-agent está corriendo"
else
    warn "kali-agent no arrancó correctamente"
    echo "  Ver logs: journalctl -u kali-agent -n 30"
fi

info "Iniciando cloudflared tunnel..."
systemctl restart cloudflared-tunnel.service
sleep 3

# ── 8. Obtener URL del tunnel ──────────────────────────────────────────────────
echo ""
echo -e "${BOLD}══════════════════════════════════════════════════════${NC}"
echo -e "${BOLD}   Instalación completada${NC}"
echo -e "${BOLD}══════════════════════════════════════════════════════${NC}"
echo ""

TUNNEL_URL=$(journalctl -u cloudflared-tunnel --since "1 min ago" --no-pager 2>/dev/null \
    | grep -oP 'https://[a-zA-Z0-9-]+\.trycloudflare\.com' | tail -1)

if [[ -n "$TUNNEL_URL" ]]; then
    WS_URL="${TUNNEL_URL/https:/wss:}"
    echo -e "${GREEN}URL del tunnel detectada:${NC}"
    echo -e "  HTTPS: ${BOLD}$TUNNEL_URL${NC}"
    echo -e "  WSS:   ${BOLD}$WS_URL${NC}"
    echo ""
    echo -e "${YELLOW}Configura el portal Django:${NC}"
    echo -e "  Edita /var/www/portal_soc/.env y establece:"
    echo -e "    ${BOLD}PENTEST_WS_URL=$WS_URL${NC}"
    echo -e "    ${BOLD}KALI_HOST=kali-tunnel${NC}"
    echo -e "  Luego reinicia gunicorn:"
    echo -e "    sudo systemctl restart gunicorn"
else
    warn "No se detectó URL del tunnel automáticamente."
    echo "  Obtén la URL con:"
    echo "    journalctl -u cloudflared-tunnel -f"
    echo "  Busca una línea como:"
    echo "    https://xxxxx.trycloudflare.com"
    echo ""
    echo -e "${YELLOW}Cuando tengas la URL, configura el portal Django:${NC}"
    echo -e "  PENTEST_WS_URL=wss://<url-del-tunnel>"
    echo -e "  sudo systemctl restart gunicorn"
fi

echo ""
echo -e "${CYAN}Comandos útiles:${NC}"
echo "  Estado:   systemctl status kali-agent cloudflared-tunnel"
echo "  Logs:     journalctl -u kali-agent -f"
echo "  Tunnel:   journalctl -u cloudflared-tunnel -f"
echo "  Config:   nano /etc/kali-agent/agent.env"
echo ""
echo -e "${YELLOW}NOTA:${NC} Con quick tunnel (sin cuenta Cloudflare), la URL cambia"
echo "cada vez que cloudflared se reinicia. Para URL fija, ver README.md."
echo ""
