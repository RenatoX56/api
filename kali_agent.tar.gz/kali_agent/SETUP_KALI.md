# Configuración del Kali — Portal SOC Pentest

## Requisitos
- Kali Linux (cualquier versión reciente)
- Acceso root
- Conexión a internet (solo saliente)

---

## Paso 1 — Subir el agente al Kali

Desde el servidor del portal (o tu PC):

```bash
scp /var/www/portal_soc/apps/pentest/kali_agent.tar.gz root@<IP-DEL-KALI>:/tmp/
```

---

## Paso 2 — Descomprimir e instalar

En el Kali:

```bash
cd /tmp
tar -xzf kali_agent.tar.gz
sudo bash kali_agent/install.sh
```

El instalador te pedirá dos datos:

**Portal URL** → presiona Enter para aceptar el valor por defecto:
```
https://200.73.23.246
```

**PENTEST_WS_INTERNAL_SECRET** → ingresa este secreto exacto:
```
7e2e1904ebc9ea0f2764b9510a40cf2b8ef08d4f5e30b40f37917791920e876f
```

---

## Paso 3 — Obtener la URL del tunnel

Al terminar la instalación, el script intentará mostrar la URL automáticamente.
Si no aparece, ejecuta:

```bash
journalctl -u cloudflared-tunnel -n 50 | grep trycloudflare
```

Busca una línea como:
```
https://abc-palabra-xyz.trycloudflare.com
```

---

## Paso 4 — Configurar el portal Django

En el servidor del portal, edita el `.env`:

```bash
nano /var/www/portal_soc/.env
```

Busca la línea:
```
PENTEST_WS_URL=wss://PENDIENTE.trycloudflare.com
```

Reemplázala con la URL del tunnel (cambia `https://` por `wss://`):
```
PENTEST_WS_URL=wss://abc-palabra-xyz.trycloudflare.com
```

Reinicia gunicorn:
```bash
sudo systemctl restart gunicorn
```

---

## Paso 5 — Verificar

En el portal, ve a la sección **Pentest** y abre una consola.
Debería conectarse y mostrar el terminal de Kali.

---

## Comandos útiles en Kali

```bash
# Ver si los servicios están corriendo
systemctl status kali-agent cloudflared-tunnel

# Logs del agente (sesiones, tokens, errores)
journalctl -u kali-agent -f

# Logs del tunnel (URL, estado de conexión)
journalctl -u cloudflared-tunnel -f

# Reiniciar todo
systemctl restart kali-agent cloudflared-tunnel

# Ver URL actual del tunnel
journalctl -u cloudflared-tunnel --since "10 min ago" | grep trycloudflare
```

---

## Importante — URL del tunnel

Con la instalación por defecto se usa un **quick tunnel** de Cloudflare:

- ✅ No requiere cuenta ni dominio
- ✅ Funciona inmediatamente
- ⚠️ La URL **cambia cada vez que cloudflared se reinicia**

Cada vez que la URL cambie, hay que actualizar `PENTEST_WS_URL` en el portal y reiniciar gunicorn.

Si quieres una URL fija, consulta la sección **Named tunnel** del `README.md`.

---

## Troubleshooting

| Problema | Solución |
|----------|----------|
| "Token inválido" en el terminal | El secreto no coincide — verificar que sea igual en el `.env` del portal y en `/etc/kali-agent/agent.env` |
| Terminal en blanco / no conecta | Verificar que `PENTEST_WS_URL` en el portal tenga la URL correcta con `wss://` |
| cloudflared no arranca | `journalctl -u cloudflared-tunnel -n 30` para ver el error |
| kali-agent no arranca | `journalctl -u kali-agent -n 30` para ver el error |
| Quiero cambiar la configuración | `nano /etc/kali-agent/agent.env` → `systemctl restart kali-agent` |
