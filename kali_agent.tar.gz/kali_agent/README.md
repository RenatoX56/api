# Kali WS Agent — Portal SOC

Agente WebSocket PTY para conectar el Portal SOC con una máquina Kali Linux
**sin abrir puertos inbound** en Kali, usando un tunnel de cloudflared.

## Arquitectura

```
Browser (portal)
    │  WSS
    ▼
cloudflared edge (Cloudflare)
    │  WSS  (tunnel inverso — Kali inicia la conexión)
    ▼
cloudflared (proceso en Kali)  →  127.0.0.1:8765
                                       │
                                   kali-agent.py
                                       │ valida token
                                       ▼
                               Portal Django (:443)
                               /pentest/api/validate-token/
                                       │ ok
                                       ▼
                               bash PTY session
```

Kali solo hace conexiones **salientes** — no necesita abrir ningún puerto.

---

## Instalación rápida (en Kali)

```bash
# 1. Copiar la carpeta kali_agent al Kali
scp -r kali_agent/ root@<kali-ip>:/tmp/kali-agent/

# 2. En Kali, ejecutar el instalador
ssh root@<kali-ip>
sudo bash /tmp/kali-agent/install.sh
```

El instalador:
- Instala Python + dependencias en `/opt/kali-agent/venv/`
- Instala `cloudflared`
- Configura `/etc/kali-agent/agent.env`
- Registra e inicia los servicios `kali-agent` y `cloudflared-tunnel`
- Muestra la URL del tunnel para configurar el portal

---

## Configuración manual

### 1. Generar el secreto compartido

En cualquier máquina con Python:
```bash
python3 -c "import secrets; print(secrets.token_hex(32))"
# Ejemplo: a3f8c2d1e4b5a6f7...
```

### 2. Configurar el portal Django

Editar `/var/www/portal_soc/.env`:
```env
PENTEST_WS_INTERNAL_SECRET=<secreto-generado>
KALI_HOST=kali-pentest
PENTEST_WS_URL=wss://<url-del-tunnel>
```

Reiniciar gunicorn:
```bash
sudo systemctl restart gunicorn
```

### 3. Configurar el agente en Kali

Crear `/etc/kali-agent/agent.env`:
```env
PORTAL_URL=https://200.73.23.246
PENTEST_WS_INTERNAL_SECRET=<mismo-secreto-del-portal>
AGENT_PORT=8765
AGENT_HOST=127.0.0.1
SHELL=/bin/bash
VERIFY_SSL=false
LOG_LEVEL=INFO
```

---

## Tunnel rápido vs. named tunnel

### Quick tunnel (sin cuenta Cloudflare)

URL aleatoria que cambia cada vez que cloudflared se reinicia.

```bash
cloudflared tunnel --url http://127.0.0.1:8765
```

**Problema:** hay que actualizar `PENTEST_WS_URL` en el portal cada vez que
cambia la URL. Solo recomendado para pruebas.

### Named tunnel (URL fija — recomendado para producción)

Requiere cuenta gratuita en Cloudflare y un dominio (puede ser de prueba).

```bash
# 1. Login en Cloudflare
cloudflared login

# 2. Crear tunnel (nombre: soc-kali)
cloudflared tunnel create soc-kali

# 3. Crear config
mkdir -p ~/.cloudflared
cat > ~/.cloudflared/config.yml << EOF
tunnel: soc-kali
credentials-file: /root/.cloudflared/<UUID>.json

ingress:
  - hostname: kali.tu-dominio.com
    service: http://127.0.0.1:8765
  - service: http_status:404
EOF

# 4. Agregar DNS CNAME en Cloudflare dashboard
cloudflared tunnel route dns soc-kali kali.tu-dominio.com

# 5. Servicio systemd (reemplazar el quick tunnel)
cat > /etc/systemd/system/cloudflared-tunnel.service << 'EOF'
[Unit]
Description=Cloudflared Named Tunnel — Portal SOC Pentest
After=network.target kali-agent.service

[Service]
Type=simple
User=root
ExecStart=/usr/local/bin/cloudflared tunnel run soc-kali
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl restart cloudflared-tunnel
```

Con named tunnel, el portal usa `PENTEST_WS_URL=wss://kali.tu-dominio.com` de forma permanente.

---

## Operación

```bash
# Ver estado de los servicios
systemctl status kali-agent cloudflared-tunnel

# Logs en tiempo real
journalctl -u kali-agent -f
journalctl -u cloudflared-tunnel -f

# Ver URL del tunnel (quick tunnel)
journalctl -u cloudflared-tunnel --since "5 min ago" | grep trycloudflare

# Reiniciar
systemctl restart kali-agent cloudflared-tunnel

# Detener
systemctl stop kali-agent cloudflared-tunnel
```

---

## Troubleshooting

| Síntoma | Causa probable | Solución |
|---------|---------------|----------|
| Terminal muestra "Token inválido" | `PENTEST_WS_INTERNAL_SECRET` no coincide | Verificar que el secreto sea idéntico en portal y agente |
| Terminal se conecta pero queda en blanco | cloudflared no está corriendo | `systemctl restart cloudflared-tunnel` |
| `VERIFY_SSL=false` necesario | Portal con certificado autofirmado | Normal para IP directa sin dominio |
| Sesión se desconecta sola | Ping timeout | Normal si la pestaña queda inactiva; usar "Reconectar" |
| URL del tunnel cambia | Quick tunnel reiniciado | Usar named tunnel para producción |

---

## Seguridad

- El agente escucha **solo en `127.0.0.1`** — no expuesto directamente a red
- cloudflared crea el tunnel **saliente** — sin puertos inbound
- Cada sesión requiere un **token de un solo uso** (90 segundos de vida) emitido por el portal
- El secreto interno protege el endpoint de validación de tokens
- Las sesiones PTY corren como `root` en Kali — usar solo en entornos de pentesting autorizados
