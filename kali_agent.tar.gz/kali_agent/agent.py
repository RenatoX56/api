#!/usr/bin/env python3
"""
Kali WS Agent — Portal SOC Pentest
===============================================================
Servidor WebSocket que expone una sesión PTY (bash) por conexión.
Cada cliente debe presentar un token de un solo uso emitido por
el portal Django, que se valida contra el endpoint /pentest/api/validate-token/.

Flujo:
  Browser → cloudflared tunnel → este agente → bash PTY
                                      ↓
                              Portal Django (validación token)

Protocolo WS:
  Cliente → servidor:
    {"input": "<texto>"}          — entrada teclado
    {"resize": true, "rows": N, "cols": M}  — cambio de tamaño

  Servidor → cliente:
    {"output": "<base64>"}        — salida PTY
    {"error": "<mensaje>"}        — error de autenticación

Uso:
  python3 agent.py
  AGENT_PORT=8765 PORTAL_URL=https://200.73.23.246 python3 agent.py
"""

import asyncio
import base64
import fcntl
import json
import logging
import os
import pty
import signal
import struct
import subprocess
import sys
import termios
from urllib.parse import parse_qs, urlparse

import requests
import websockets

# ── Configuración ──────────────────────────────────────────────────────────────
PORTAL_URL      = os.environ.get('PORTAL_URL',      'https://200.73.23.246')
INTERNAL_SECRET = os.environ.get('PENTEST_WS_INTERNAL_SECRET', '')
LISTEN_HOST     = os.environ.get('AGENT_HOST',      '127.0.0.1')   # solo localhost; cloudflared hace el tunnel
LISTEN_PORT     = int(os.environ.get('AGENT_PORT',  '8765'))
SHELL           = os.environ.get('SHELL',           '/bin/bash')
VERIFY_SSL      = os.environ.get('VERIFY_SSL',      'true').lower() != 'false'
LOG_LEVEL       = os.environ.get('LOG_LEVEL',       'INFO').upper()

logging.basicConfig(
    level=getattr(logging, LOG_LEVEL, logging.INFO),
    format='[%(asctime)s] %(levelname)s %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
)
log = logging.getLogger('kali-agent')


# ── Validación de token ────────────────────────────────────────────────────────

def validate_token_sync(token: str) -> dict | None:
    """Llama al portal Django para validar el token. Bloqueante — ejecutar en executor."""
    if not INTERNAL_SECRET:
        log.error('PENTEST_WS_INTERNAL_SECRET no configurado — rechazando todas las conexiones')
        return None
    try:
        r = requests.get(
            f'{PORTAL_URL}/pentest/api/validate-token/',
            params={'token': token},
            headers={'X-Internal-Secret': INTERNAL_SECRET},
            timeout=5,
            verify=VERIFY_SSL,
        )
        r.raise_for_status()
        data = r.json()
        return data if data.get('valid') else None
    except Exception as exc:
        log.error('Error validando token: %s', exc)
        return None


# ── I/O PTY ───────────────────────────────────────────────────────────────────

async def pty_to_ws(master_fd: int, websocket, loop: asyncio.AbstractEventLoop):
    """Lee del PTY master y reenvía al WebSocket como base64."""
    while True:
        try:
            data = await loop.run_in_executor(None, _read_fd, master_fd)
            if not data:
                break
            encoded = base64.b64encode(data).decode('ascii')
            await websocket.send(json.dumps({'output': encoded}))
        except (OSError, websockets.ConnectionClosed):
            break


def _read_fd(fd: int) -> bytes:
    """Lee hasta 4096 bytes del fd. Retorna b'' si el fd se cierra."""
    try:
        return os.read(fd, 4096)
    except OSError:
        return b''


async def ws_to_pty(websocket, master_fd: int):
    """Lee mensajes del WebSocket y los escribe al PTY master."""
    async for message in websocket:
        try:
            msg = json.loads(message)
        except json.JSONDecodeError:
            continue
        try:
            if 'input' in msg:
                data = msg['input'].encode('utf-8', errors='replace')
                os.write(master_fd, data)
            elif msg.get('resize'):
                rows = int(msg.get('rows', 24))
                cols = int(msg.get('cols', 80))
                winsize = struct.pack('HHHH', rows, cols, 0, 0)
                fcntl.ioctl(master_fd, termios.TIOCSWINSZ, winsize)
        except OSError:
            break


# ── Handler principal ──────────────────────────────────────────────────────────

async def handle(websocket, path=None):
    """Maneja una conexión WebSocket: valida token → spawn PTY → proxy I/O."""

    # Compatibilidad con websockets < 11 y >= 11
    req_path = getattr(websocket, 'path', None) or path or '/'
    qs       = parse_qs(urlparse(req_path).query)
    token    = qs.get('token', [None])[0]

    remote = websocket.remote_address if hasattr(websocket, 'remote_address') else '?'
    log.info('Conexión entrante desde %s', remote)

    if not token:
        await websocket.send(json.dumps({'error': 'Token requerido'}))
        await websocket.close(1008, 'Token requerido')
        return

    loop = asyncio.get_event_loop()
    info = await loop.run_in_executor(None, validate_token_sync, token)

    if not info:
        await websocket.send(json.dumps({'error': 'Token inválido o expirado'}))
        await websocket.close(1008, 'Token inválido')
        log.warning('Token rechazado desde %s', remote)
        return

    username     = info.get('username', 'unknown')
    console_name = info.get('console_name', '?')
    log.info('Sesión autorizada — user=%s console=%s', username, console_name)

    # Abrir PTY
    master_fd, slave_fd = pty.openpty()

    env = {
        **os.environ,
        'TERM':      'xterm-256color',
        'COLORTERM': 'truecolor',
        'LANG':      'en_US.UTF-8',
        'USER':      'root',
        'HOME':      '/root',
        # Mostrar en el prompt quién está conectado
        'SOC_USER':  username,
    }

    proc = subprocess.Popen(
        [SHELL, '-l'],
        stdin=slave_fd, stdout=slave_fd, stderr=slave_fd,
        close_fds=True,
        env=env,
        preexec_fn=os.setsid,
        cwd='/root',
    )
    os.close(slave_fd)

    log.info('PTY spawn PID=%d — user=%s', proc.pid, username)

    try:
        await asyncio.gather(
            pty_to_ws(master_fd, websocket, loop),
            ws_to_pty(websocket, master_fd),
            return_exceptions=True,
        )
    finally:
        # Terminar proceso si sigue vivo
        try:
            proc.send_signal(signal.SIGKILL)
        except (ProcessLookupError, OSError):
            pass
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            pass
        try:
            os.close(master_fd)
        except OSError:
            pass
        log.info('Sesión cerrada — user=%s PID=%d', username, proc.pid)


# ── Main ───────────────────────────────────────────────────────────────────────

async def main():
    if not INTERNAL_SECRET:
        log.error('⚠  PENTEST_WS_INTERNAL_SECRET está vacío — el agente no podrá validar tokens')
        log.error('   Configura la variable en /etc/kali-agent/agent.env')

    log.info('Kali WS Agent iniciando...')
    log.info('  Escuchando en  %s:%d', LISTEN_HOST, LISTEN_PORT)
    log.info('  Portal URL:    %s', PORTAL_URL)
    log.info('  SSL verify:    %s', VERIFY_SSL)

    async with websockets.serve(
        handle,
        LISTEN_HOST,
        LISTEN_PORT,
        ping_interval=20,
        ping_timeout=20,
        close_timeout=10,
    ):
        log.info('Agente listo. Esperando conexiones...')
        await asyncio.Future()  # correr indefinidamente


if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        log.info('Agente detenido por el usuario.')
        sys.exit(0)
